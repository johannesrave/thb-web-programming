const msg = document.getElementById("message");
msg.innerHTML = "Welcome to our little site!<br>" +
    "Make yourself at home!";